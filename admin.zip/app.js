$(document).ready(function() {
    $(location).attr('href', 'login/login.php');
});