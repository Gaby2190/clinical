<!----------------------------------------------------------------------------footer section start--------------------------------------------------------->
<footer class="dashboard">
    <p>&copy 2022 Collective. All Rights Reserved | Design by <a href="https://sidatagroup.com/" target="_blank" class="text-primary">Data-Group.</a></p>
</footer>
<!--footer section end-->